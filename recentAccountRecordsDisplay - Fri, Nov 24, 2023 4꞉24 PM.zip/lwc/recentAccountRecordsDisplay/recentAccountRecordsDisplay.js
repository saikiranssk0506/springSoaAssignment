import { LightningElement, wire } from 'lwc';
import getAccountData from '@salesforce/apex/accountHandler.latestAccountMethod'
const columnsList = [
     { label: 'Id', fieldName: 'Id'},
    { label: 'Name', fieldName: 'Name' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
    { label: 'CreatedDate', fieldName: 'CreatedDate', type: 'date' }
    ]
export default class RecentAccountRecordsDisplay extends LightningElement {
    columnsList=columnsList
    accData=[]
    @wire(getAccountData)
    dataHandlermethod({data,error}){
        if(data){
            this.accData=data;
            console.log(data);
            console.log(JSON.stringify(this.accData))
            
        }if(error){
            console.log(error);

        }
    }
}